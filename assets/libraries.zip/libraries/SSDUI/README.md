# SSDUI

(Aim to be) A generic UI framework for embedded devices, strongly dependent on C++20 and standard library.

## TODO

1. Transfer toolchain to GCC>=12
2. Unit test environment
3. Test on more platforms & screens
4. Color support
5. Examples
