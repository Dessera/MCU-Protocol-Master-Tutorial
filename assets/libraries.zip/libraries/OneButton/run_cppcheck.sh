cppcheck --enable=all --suppressions-list=suppressions.txt --language=c++ -I./src --error-exitcode=2 ./src/*
